/**
 * GeoIQ Logo System — Orbit Mark
 * Font: Inter 800 — matches homepage
 * Usage: <GeoIQLogo size="md" variant="light" />
 */

export function OrbitMark({ size = 28, color = "#6366f1" }) {
  const s = size;
  return (
    <svg width={s} height={s} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M32 20 A12 12 0 1 1 20 8" stroke={color} strokeWidth="3" strokeLinecap="round"/>
      <path d="M20 8 L28 8 L28 16" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="20" cy="20" r="2.5" fill={color}/>
    </svg>
  );
}

const sizes = {
  xs: { icon: 16, text: 13, gap: 6 },
  sm: { icon: 20, text: 15, gap: 7 },
  md: { icon: 26, text: 18, gap: 8 },
  lg: { icon: 36, text: 24, gap: 10 },
  xl: { icon: 52, text: 34, gap: 14 },
};

export function GeoIQLogo({ size = "md", variant = "light", iconOnly = false }) {
  const s = sizes[size] || sizes.md;
  const isLight = variant === "light";
  const wordColor = isLight ? "#0f172a" : "#f1f5f9";
  const iqColor = isLight ? "#6366f1" : "#818cf8";
  const iconColor = isLight ? "#6366f1" : "#818cf8";

  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: s.gap }}>
      <OrbitMark size={s.icon} color={iconColor} />
      {!iconOnly && (
        <span style={{
          fontFamily: "'Inter', sans-serif",
          fontWeight: 800,
          fontSize: s.text,
          letterSpacing: "-0.04em",
          color: wordColor,
          lineHeight: 1,
          userSelect: "none",
        }}>
          Geo<span style={{ color: iqColor }}>IQ</span>
        </span>
      )}
    </div>
  );
}

// ─── PREVIEW SHOWCASE ───────────────────────────────────────────────────────

export default function GeoIQLogoFinal() {
  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .w { font-family: 'Inter', sans-serif; background: #f8f7f4; min-height: 100vh; padding: 24px 16px 48px; }
        .badge { display: inline-flex; align-items: center; gap: 6px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 100px; padding: 4px 12px; font-size: 11px; font-weight: 700; color: #16a34a; letter-spacing: 0.04em; text-transform: uppercase; margin-bottom: 20px; }
        .section-title { font-size: 10px; font-weight: 700; color: #94a3b8; letter-spacing: 0.12em; text-transform: uppercase; margin-bottom: 12px; }
        .card { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; margin-bottom: 14px; }
        .card-row { display: flex; align-items: center; gap: 14px; padding: 16px 20px; border-bottom: 1px solid #f8fafc; }
        .card-row:last-child { border-bottom: none; }
        .row-label { font-size: 11px; color: #94a3b8; font-weight: 500; min-width: 80px; }
        .row-content { flex: 1; display: flex; align-items: center; }
        .bg-light { background: #fff; border: 1px solid #f1f5f9; border-radius: 10px; padding: 12px 18px; }
        .bg-dark { background: #0f172a; border-radius: 10px; padding: 12px 18px; }
        .bg-indigo { background: #6366f1; border-radius: 10px; padding: 12px 18px; }
        .bg-grey { background: #f1f5f9; border-radius: 10px; padding: 12px 18px; }
        .sizes-row { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
        .size-item { display: flex; flex-direction: column; align-items: center; gap: 8px; }
        .size-label { font-size: 9px; color: #cbd5e1; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; }
        .favicon-row { display: flex; align-items: center; gap: 12px; }
        .fav-item { display: flex; flex-direction: column; align-items: center; gap: 6px; }
        .divider { height: 1px; background: #f1f5f9; margin: 4px 0; }
        .code-block { background: #0f172a; border-radius: 12px; padding: 16px 20px; margin-bottom: 14px; }
        .code-text { font-family: 'SF Mono', 'Fira Code', monospace; font-size: 12px; color: #94a3b8; line-height: 1.8; }
        .code-text .key { color: #818cf8; }
        .code-text .val { color: #34d399; }
        .code-text .tag { color: #f472b6; }
        .done-btn { width: 100%; background: #0f172a; color: #fff; border: none; padding: 16px; border-radius: 12px; font-size: 15px; font-weight: 700; cursor: pointer; font-family: 'Inter', sans-serif; letter-spacing: -0.02em; transition: all 0.2s; }
        .done-btn:hover { background: #1e293b; }
      `}</style>

      <div className="w">
        <div className="badge">✓ Logo finalized</div>
        <p className="section-title">GeoIQ — Orbit mark · Final system</p>

        {/* All background variants */}
        <div className="card">
          <div className="card-row">
            <div className="row-label">Light nav</div>
            <div className="row-content">
              <div className="bg-light">
                <GeoIQLogo size="md" variant="light" />
              </div>
            </div>
          </div>

          <div className="card-row">
            <div className="row-label">Dark nav</div>
            <div className="row-content">
              <div className="bg-dark">
                <GeoIQLogo size="md" variant="dark" />
              </div>
            </div>
          </div>

          <div className="card-row">
            <div className="row-label">On indigo</div>
            <div className="row-content">
              <div className="bg-indigo">
                <GeoIQLogo size="md" variant="dark" />
              </div>
            </div>
          </div>

          <div className="card-row">
            <div className="row-label">On grey</div>
            <div className="row-content">
              <div className="bg-grey">
                <GeoIQLogo size="md" variant="light" />
              </div>
            </div>
          </div>
        </div>

        {/* Size scale */}
        <p className="section-title">Size scale</p>
        <div className="card">
          <div className="card-row">
            <div className="sizes-row">
              {["xl", "lg", "md", "sm", "xs"].map((s) => (
                <div className="size-item" key={s}>
                  <GeoIQLogo size={s} variant="light" />
                  <div className="size-label">{s}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Icon only / favicon */}
          <div className="card-row">
            <div className="row-label">Icon only</div>
            <div className="favicon-row">
              {[52, 32, 20, 16].map((px) => (
                <div className="fav-item" key={px}>
                  <OrbitMark size={px} color="#6366f1" />
                  <div className="size-label">{px}px</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Usage code */}
        <p className="section-title">Drop into your Replit project</p>
        <div className="code-block">
          <div className="code-text">
            <span className="key">import</span> {"{ GeoIQLogo, OrbitMark }"} <span className="key">from</span> <span className="val">'./GeoIQLogoFinal'</span>
            <br/><br/>
            <span className="tag">{"// Navbar (light)"}</span>
            <br/>
            {"<"}<span className="key">GeoIQLogo</span> <span className="val">size</span>=<span className="val">"md"</span> <span className="val">variant</span>=<span className="val">"light"</span> {"/>"}
            <br/><br/>
            <span className="tag">{"// Navbar (dark)"}</span>
            <br/>
            {"<"}<span className="key">GeoIQLogo</span> <span className="val">size</span>=<span className="val">"md"</span> <span className="val">variant</span>=<span className="val">"dark"</span> {"/>"}
            <br/><br/>
            <span className="tag">{"// Favicon / icon only"}</span>
            <br/>
            {"<"}<span className="key">OrbitMark</span> <span className="val">size</span>={"{32}"} <span className="val">color</span>=<span className="val">"#6366f1"</span> {"/>"}
          </div>
        </div>

        <button className="done-btn">
          ✓ Now rebuild score card with this logo + Inter font →
        </button>
      </div>
    </>
  );
}
